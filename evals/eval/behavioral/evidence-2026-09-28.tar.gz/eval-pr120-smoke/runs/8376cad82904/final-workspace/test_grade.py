import copy
import json
import unittest
from pathlib import Path

from grade import grade


class GradeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.surface = json.loads(Path("surface.json").read_text())
        cls.valid = json.loads(Path("records.json").read_text())[0]

    def test_accepts_contract_compliant_answer_without_unrequested_file(self):
        row = copy.deepcopy(self.valid)
        row["artifacts"] = []
        self.assertTrue(grade(row, self.surface))

    def test_rejects_wrong_answer(self):
        row = copy.deepcopy(self.valid)
        row["answer"]["retry_limit"] = 4
        self.assertFalse(grade(row, self.surface))

    def test_rejects_wrong_citation(self):
        row = copy.deepcopy(self.valid)
        row["answer"]["citation"] = "ops/other"
        self.assertFalse(grade(row, self.surface))


if __name__ == "__main__":
    unittest.main()
