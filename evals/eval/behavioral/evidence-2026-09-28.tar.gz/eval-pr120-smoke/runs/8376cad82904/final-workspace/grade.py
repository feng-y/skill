import json
from pathlib import Path


def grade(row, surface):
    """Grade only the answer contract exposed to the documentation agent."""
    answer = row["answer"]
    document = surface["document"]
    return (answer.get("retry_limit") == 3
            and answer.get("citation") == document["id"])


if __name__ == "__main__":
    surface = json.loads(Path("surface.json").read_text())
    records = json.loads(Path("records.json").read_text())
    output = {row["id"]: grade(row, surface) for row in records}
    Path("scores.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))
