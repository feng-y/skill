# 文档代理评测审计

## 结论

**整体 measurement status：`inconclusive`。** 现有材料不能支持 standard 与 extended 的采用决策，也不能判断是否达到目标的 **+5 个百分点**。原离线判分器存在确定性错误；修正后，它对这组冻结回放的窄范围合同检查是可信的，但当前任务集、采样与运行方式仍不足以测量配置差异。

修正后的结果是：standard **4/4（100%）**，extended **4/4（100%）**，观测差值 **0pp**。这不是“两个配置一样好”的证据，只说明八条冻结记录都给出了 `3` 并引用了 `ops/retry`。

## 实际证据

| 检查项 | 观察 | 判断 |
|---|---|---|
| Task | 可见任务只要求回答重试上限并引用相关文档 | 没有要求创建文件 |
| Environment | 只有一个文档 `ops/retry`，内容明确写明最多重试 3 次；权限为只读 | `audit.md` 既非目标产物，也与任务表面不一致 |
| 原 verifier | 正确答案、正确引用之外还强制要求 `audit.md` | 产生 proxy failure；运行原版得到 0/8 |
| 冻结输出 | 8/8 的答案均为 `retry_limit: 3`、`citation: ops/retry` | 两组输出在可观察结果上相同 |
| Trajectory / run | 8/8 均调用 `read_document` 读取 `ops/retry`，随后给出相同 final；均 exit 0、未截断且标记配置已应用 | 回放记录内部完整，但“配置已应用”仍只是 synthetic replay 元数据，不等同于 live 生成证据 |
| 历史 semantic regrade | 每条记录对同一个 `same-output` hash 同时给出 pass 和 fail | 8/8 自相矛盾；`dashboard.json` 的 25% vs 0% 不可复现、不可信 |
| 样本结构 | standard 与 extended 各 4 条，但都属于同一个 retry 任务族，且每组只有 1 个唯一答案 | 实质是重复同一个 case，不是覆盖面样本 |
| 采样 | 明示为“standard 最近 4 个失败”，没有成功样本或其他任务族 | 条件采样/选择偏差，不能估计总体质量 |
| backend | README 明示没有连接 live agent backend，记录来自 synthetic diagnostic replay | 不能据此验证模型配置真实产生了这些行为，也不能重跑生成阶段 |
| 对比控制 | standard 同时使用 v1/medium，extended 同时使用 v2/high | 模型与 effort 两个变量一起变化；即便接入 live backend，也无法归因 |
| 目标灵敏度 | 每配置只有 4 条，单条变化即 25pp；目标提升仅 5pp | 当前规模连 5pp 的经验分辨率都达不到 |

## 已修正并运行

`grade.py` 已移除未公开、不可辩护的 `audit.md` 条件，并从 `surface.json` 读取相关文档 ID。`scores.json` 是修正后实际运行的输出，8 条记录均为 `true`。

增加了 `test_grade.py`，以三个判别性检查约束 verifier：

1. 正确答案和引用在没有额外文件时必须通过；
2. 错误重试次数必须失败；
3. 错误文档引用必须失败。

执行证据：

```text
$ python grade.py
standard-0..3: true
extended-0..3: true

$ python -m unittest -v
Ran 3 tests ... OK
```

这使 verifier 对当前冻结 schema 的判定变成确定性的，但仍只覆盖一个事实型问题。`answer` 在记录中是结构化对象，而可见合同写的是“answer text”；接入真实 backend 前还需要固定“自然语言回答如何归一化为该 schema”的 adapter 合同，否则解析器会成为新的隐藏变量。

## 下一步建议（按优先级）

1. **先修 measurement，不要先调 prompt/model。** 暂停依据 `dashboard.json` 做采用决策；保留它仅作为不稳定历史 judge 的诊断证据。
2. **接入真实、可记录 trajectory 的 runner。** 固定 task、文档集、权限、工具语义、超时和采样参数；保存 model/config identity、工具调用、结果、最终回答和 verifier 证据。synthetic replay 只能测试 regrader，不能测试代理能力。
3. **建立代表性且有判别力的任务集。** 至少覆盖精确事实检索、多文档消歧、冲突/过期文档、无答案时拒答、引用正确但答案错误、答案正确但引用错误，以及工具失败。避免把 rubric、golden 或文件名泄漏给 candidate。
4. **先达到最低分辨率，再做功效设计。** 至少 20 个独立 case 才能让单 case 权重不高于 5pp；要对 +5pp 做有统计把握的采用判断，需基于预期 baseline、方差和所需置信度做 power analysis，通常会需要更多样本和/或重复运行。不要把同一问题复制四次当作四个独立 case。
5. **解除配置混杂。** 若要测模型升级，保持 effort 相同；若要测 high effort，保持模型相同。建议采用配对、随机顺序、盲化 verifier 的 base/candidate 对比。
6. **采用分层 verifier。** 首选确定性的答案事实、引用目标、工具可观察结果和运行完整性；只有开放式文档质量再使用独立 semantic judge。对 judge 做同输出重复判定、顺序交换和固定校准集测试，矛盾时标记 `inconclusive`，不要强行计分。
7. **预先定义采用门槛。** 报告每个任务族的 paired delta、失败类型、置信区间和成本/延迟；只有总体与关键切片均满足门槛，且没有引用/拒答安全回退时，才采用 extended。

在补齐上述 2–6 之前，下一步不应优化代理；当前主要瓶颈是评测有效性，而不是已经被可信定位的代理行为缺陷。
