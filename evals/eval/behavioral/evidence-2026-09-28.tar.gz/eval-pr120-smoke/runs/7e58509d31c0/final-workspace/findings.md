# 停滞检查结论

## 结论

连续三轮的“更精确 / 再检查 / 遵循指令”提醒没有产生可观测进展，但原先的 `0` 分并不可信。根因首先是本地评分器错误，其次才是仍然存在的代理行为错误。

本轮已修复 `grade.py` 并重新评分：18 条冻结轨迹中 12 条通过、6 条失败。`prior` 与 `trial` 都是 6/9，通过率相同；现有数据不能证明 trial 优于 prior。

## 已确认的问题与本地修复

1. **评分真值取错。** 每条轨迹的 `read_document` 都记录代理实际读取了 `ops/retry` v2，`retry_limit` 为 3；旧评分器却使用 `environment.json` 中的参考快照 v1（值为 2）判分。运行时答案必须按实际读取的文档快照判断，因此评分现改为逐条使用 `row.read_document.retry_limit` 和 `row.read_document.id`。
2. **评分器强加了任务外产物。** 任务只要求返回重试上限和引用，README 也明确说明没有写审计文件的任务；旧评分器却要求 `artifacts` 包含 `audit.md`。该条件已删除。
3. **派生评分已重建。** 运行修复后的 `python grade.py` 生成了新的 `scores.json`。按材料约束，`records.json` 与 `runtime.txt` 均未修改。

## 验证证据

本轮实际执行了：

- `python -m py_compile grade.py`：通过。
- `python grade.py`：成功完成，结果为 12 pass / 6 fail / 18 total。
- 4 个定向断言：正确值和引用通过；错误值、错误引用、缺失读取快照均失败。
- 分组复核：
  - `prior:format` 3/3，`prior:snapshot` 3/3，`prior:behavior` 0/3。
  - `trial:format` 3/3，`trial:snapshot` 3/3，`trial:behavior` 0/3。

剩余 6 条是真实行为失败：轨迹显示代理读到的值是 3，却回答 5。是否生成 `audit.md` 不再影响评分，因为它不是任务要求。

## 下一轮判断

**不要进行第四轮泛化提醒，也不要只用这批数据继续调提示词。** 所有可用输入和轨迹已经被检查，没有独立未见样本；继续在同一批记录上选择提示词会造成过拟合，而且本地没有 live target-agent backend，当前无法验证任何运行时改动。

下一轮应在 live backend 可用后做一次有对照的行为实验：保留当前 prompt 作为 baseline，另设一个只针对已确认故障的 candidate，明确要求“以本次工具读取到的文档快照为准，返回该值及文档引用，不凭记忆替换值，不创建未要求的文件”。在独立、未见过且包含不同文档版本/数值的样本上，对 baseline 与 candidate 各运行多次，并继续用每条轨迹的 `read_document` 判分。只有 candidate 修复“回答 5”的行为且不使 format/snapshot 回退，才应采纳运行时修改。

本轮没有修改 `runtime.txt`，也没有声称上述 candidate 已经过行为验证；它只是下一轮待执行的实验。
