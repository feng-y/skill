import json
from pathlib import Path


def grade(row):
    """Grade the response against the document captured in its own trace."""
    document = row["read_document"]
    return (row["exit"] == 0
            and not row["truncated"]
            and row["answer"].get("retry_limit") == document["retry_limit"]
            and row["answer"].get("citation") == document["id"]
            and not row["artifacts"])


if __name__ == "__main__":
    records = json.loads(Path("records.json").read_text())
    output = {row["id"]: grade(row) for row in records}
    Path("scores.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))
