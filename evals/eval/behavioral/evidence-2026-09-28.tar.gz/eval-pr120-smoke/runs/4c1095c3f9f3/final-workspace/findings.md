# 停滞排查结论

## 结论

本轮找到了并修复了一个本地评分错误。修复后，18 条冻结 trace 中有 6 条通过；`prior` 和 `trial` 均为 3/9（33.3%），没有观察到 trial 相对 prior 的改善。因此不应进行第四轮同类“提醒代理更仔细”的修改。

当前真正可见的行为问题有两个：

- 6 条 `snapshot` trace 读到了 `ops/retry` v2，正确回答了重试上限 3，但越权生成了 `audit.md`，因此失败。
- 6 条 `behavior` trace 同样读到了重试上限 3，却回答 5，并且越权生成了 `audit.md`，因此失败。

其余 6 条 `format` trace 正确回答 3、引用 `ops/retry`，且没有生成额外文件，均通过。

## 本地修复

`grade.py` 原先存在两处与任务契约相反的逻辑：

1. 它用 `environment.json` 的旧快照（`ops/retry` v1、上限 2）评价所有 trace，而每条 trace 记录的实际已读文档都是 v2、上限 3。
2. 它要求产出 `audit.md` 才通过，但任务只要求返回重试上限和引用，README 也明确说明没有审计文件任务。

现已改为：

- 以每条记录自身的 `read_document` 快照作为该次执行的事实来源；
- 要求答案的 `retry_limit` 和 `citation` 与实际读取文档一致；
- 要求正常退出、结果未截断且不生成额外 artifact。

按要求，`records.json` 和 `runtime.txt` 均未修改。`environment.json` 保留不动，作为造成旧评分错位的参考快照证据。

## 已执行验证

执行了：

```text
python -m py_compile grade.py
python grade.py
```

并对结果执行了断言检查：记录数为 18、通过数为 6、`prior=3/9`、`trial=3/9`，且只有 `format` trace 通过。所有断言通过，结果已写入 `scores.json`。

还核对了全部冻结记录：18 条的 `read_document` 都是 `ops/retry` v2、上限 3；所有进程均以 0 退出且没有截断。因而当前失败不是执行器退出或输出截断造成的。

### 验证判定

- **Claim：本地评分器现在执行 README 所述契约。Verdict：proven。** 直接契约检查证明一条正确、无副作用的 trace 会通过；错误上限、错误引用、额外 `audit.md`、非零退出和截断这 5 个实质反例都会失败。`git diff --check` 通过，且 `records.json`、`runtime.txt` 与仓库基线一致。
- **Claim：目标代理行为已经修复。Verdict：unproven。** 本轮没有 live backend，也没有新行为 trace；6/18 只是对冻结 artifact 的正确重评分，不能证明候选 prompt 的效果。

## 下一轮判断

下一轮应停止追加泛化提醒，改做一次新的、可判别的行为实验：

1. 等 live target-agent backend 可用后，再修改 runtime；当前环境没有该后端，不能把任何 prompt 改动宣称为已验证修复。
2. 待测的单一假设应是：明确要求“只以本次实际读取的文档为准，忽略旧快照或记忆；只返回请求的答案与引用，不创建文件”，能否同时消除错误数值和额外 artifact。
3. 使用新的独立样本运行 baseline 与该单一变体，至少保留当前三类覆盖（正确输出、快照来源、行为冲突）和重复运行；不要用本轮已全部查看的 18 条记录作为唯一选择集。
4. 用已修复的评分契约评估新 trace，并分别报告“答案/引用正确率”和“无额外 artifact 率”，避免总分再次掩盖故障类型。

本轮只验证了离线评分修复和既有 trace 的重新评分；尚未执行新的目标代理行为运行，也未验证上述 runtime 文案。
