审计与修复已完成，结论写入 [findings.md](/code/b/skill-eval-runs/eval-pr120-smoke/runs/c249a2131e8e/workspace/findings.md:1)。

核心结论：

- 原评分器错误要求任务未声明的 `audit.md`，导致系统性误判。
- 修复后 standard 与 extended 均为 4/4，差异 0pp。
- 当前仅覆盖一个合成场景，每组 4 条记录的分数步长为 25pp，无法判断预设的 5pp 提升。
- 因无 live backend、代表性样本和 held-out，目前不应调模型或采用 extended；应先补齐评测。

已更新：

- [grade.py](/code/b/skill-eval-runs/eval-pr120-smoke/runs/c249a2131e8e/workspace/grade.py:7)：确定性评分，并将运行故障与候选失败分离。
- [test_grade.py](/code/b/skill-eval-runs/eval-pr120-smoke/runs/c249a2131e8e/workspace/test_grade.py:9)：5 个正负向控制，全部通过。
- [scores.json](/code/b/skill-eval-runs/eval-pr120-smoke/runs/c249a2131e8e/workspace/scores.json)：重评结果。

验证结果：`python -m unittest -v` 通过 5/5；`python grade.py` 得到两配置均 100%。输入和 `runtime.txt` 未修改。