# 文档代理评测审计

## 结论

**现在不要根据这批分数调模型、effort 或 runtime，也不要据此采用 `extended`。** 原评分含有一个会系统性误判的隐藏条件；修复后，两种配置在这批冻结回放上都是 4/4（100%），观察差为 **0 个百分点**。但材料只覆盖一个简单问题、来自有偏抽样、没有真实 backend 可重跑，因而不能证明两者质量相同，也不能检出预设的 5 个百分点提升。

状态分两层：

- 狭窄的单题离线评分器：`trustworthy`。它现在只检查候选可见的答案与引用要求，并把运行故障与候选失败分开。
- standard 与 extended 的质量比较及采用决策：`inconclusive`。当前测量没有足够覆盖、分辨率或新鲜运行证据。

## 评测面与关键发现

本评测声称测量的能力是：代理读取内部文档，准确回答“重试上限是多少”，并引用相关文档。候选可见任务是 `What is the retry limit? Cite the relevant document.`；环境只有文档 `ops/retry`、只读 `read_document` 工具和两套模型/effort 配置。冻结记录来自 synthetic diagnostic replay，不是生产流量。

1. **原离线 verifier 暗加了任务不存在的交付要求。** `grade.py` 原来要求 `artifacts` 中存在 `audit.md`，但 `surface.json` 的 artifact contract 只有回答和引用，README 还明确说明不要求文件。8 条记录的 `artifacts` 都为空，所以原脚本重跑得到 standard 0/4、extended 0/4；这是 verifier failure，不是 agent failure。

2. **旧语义 grader 不一致。** 8 条记录共保存了 16 次 regrade event；同一个 `output_hash = same-output` 同时得到 `true` 与 `false`，每条记录各一次。`dashboard.json` 的 standard=25%、extended=0% 因而不能作为稳定或可复现的测量。

3. **修复后没有观察到 extended 的收益。** 8 条冻结回答都给出 `retry_limit=3` 和 `citation=ops/retry`，且运行记录均为 exit=0、未截断、`config_applied=true`。确定性重评得到：

   | 配置 | 通过/总数 | 通过率 | 相对 standard |
   |---|---:|---:|---:|
   | standard | 4/4 | 100% | — |
   | extended | 4/4 | 100% | 0 pp |

4. **这个 100% 是饱和 smoke，不是采用证据。** `surface.json` 明示样本是 standard 最近 4 个失败，未抽取成功样本或其他任务族；这会产生选择偏差。`retry-0` 到 `retry-3` 虽有四个 ID，但所有记录共享同一个可见问题、同一份文档、同一种正确答案和同一种轨迹，实质覆盖一个场景。每组 4 个二元结果的最小分数步长是 25 pp，大于事先设定的 5 pp 有用提升，无法解析该目标。

5. **没有本轮行为生成证据。** README 明示未连接 live agent backend；本次只能重评冻结合成记录，不能生成新回答或估计随机性。记录只有 `config_applied=true` 声明，没有模型构建版本、prompt/skill/harness 哈希或 provider request evidence，因此无法独立核验运行身份。也没有延迟、token 或成本数据。

6. **没有可用于泛化判断的 held-out。** 所有现有 case 已经暴露给本次审计，而且没有其他任务族。把这些 case 重新命名为 held-out 不会产生独立证据。

## 已实施的修复与运行证据

`grade.py` 已改为：

- 从权威 fixture 的文档内容和文档 ID 推导确定性 oracle，fixture 形状变化时 fail closed；
- 只评分候选可见的两个要求：正确答案、相关引用；
- 不再要求 `audit.md`；
- exit 非 0、截断或配置未生效的运行会使评测中止并要求重跑，不再伪装成候选失败；
- 输出按配置汇总的通过数和通过率。

新增 `test_grade.py`，覆盖正确样本、错误答案、错误引用、无非必要文件，以及截断运行五个负向/正向控制。实际执行：

```text
$ python -m unittest -v
Ran 5 tests in 0.001s
OK

$ python grade.py
standard: 4/4, pass_rate=1.0
extended: 4/4, pass_rate=1.0
```

逐条结果已写入 `scores.json`。`dashboard.json` 保留为历史语义评分证据，没有覆盖成新结果；后续展示应明确它已失效，当前离线结果以 `scores.json` 为准。输入 `surface.json`、`records.json` 与 `runtime.txt` 均未修改。

## 下一步建议（按优先级）

1. **先补测量，不调 actor。** 从真实文档问答任务构造有代表性的独立 case：直接事实、跨文档综合、版本/冲突消解、引用定位、文档无答案时拒绝猜测，以及不应调用无关工具的 case。抽样同时包含成功和失败，不要再只取 standard 的失败尾部。

2. **恢复可重跑 backend 和完整 run identity。** 对 standard/extended 使用相同 task、文档快照、工具语义与运行策略，记录精确模型版本、effort、runtime/prompt、harness、工具调用/结果、退出状态、截断、延迟、token 和成本。只有 `config_applied=true` 布尔值不够。

3. **在运行前冻结比较协议。** 保留不供编辑者读取的 held-out；同源变体不要跨 train/held-out。继续以 5 pp 为最小有用提升，并在看到结果前确定样本量、重复次数、置信度/功效和允许的退化边界。4 个样本/组显然不足；精确数量应根据真实基线率与 paired disagreement 的 pilot 数据计算。

4. **优先用确定性证据，语义 judge 只处理确实需要语义判断的部分。** 答案事实、引用存在性/版本、工具副作用和 run health 用程序检查；若必须使用语义 judge，要固定其身份并对相同输出做一致性重评，出现冲突时标为 grader error，而不是随机计入通过率。

5. **再决定调什么。** 若代表性集上 standard 与 extended 都饱和，把这套单题保留为回归 smoke，并转向真实困难任务；不要为了制造 headroom 添加无业务价值的陷阱。若 extended 在独立 held-out 上超过 5 pp 且成本/延迟守住边界，再考虑采用；若质量无可辨别收益，则不要为了当前 100% 继续堆 prompt 规则，是否转为成本优化需另行明确目标。

当前最重要的下一步不是“调哪个参数”，而是让评测先能稳定地区分真实文档问答能力；在此之前，任何基于 25% vs 0% 或 100% vs 100% 的配置结论都会超出证据边界。
