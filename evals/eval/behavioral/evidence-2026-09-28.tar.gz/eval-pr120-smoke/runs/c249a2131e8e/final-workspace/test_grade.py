import copy
import json
import unittest
from pathlib import Path

import grade


class GradeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        surface = json.loads(Path("surface.json").read_text())
        cls.row = json.loads(Path("records.json").read_text())[0]
        cls.retry_limit, cls.citation = grade.expected_answer(surface)

    def test_valid_answer_and_citation_pass(self):
        self.assertTrue(grade.grade(self.row, self.retry_limit, self.citation))

    def test_wrong_answer_fails(self):
        row = copy.deepcopy(self.row)
        row["answer"]["retry_limit"] += 1
        self.assertFalse(grade.grade(row, self.retry_limit, self.citation))

    def test_wrong_citation_fails(self):
        row = copy.deepcopy(self.row)
        row["answer"]["citation"] = "irrelevant/doc"
        self.assertFalse(grade.grade(row, self.retry_limit, self.citation))

    def test_unrequested_file_is_not_required(self):
        row = copy.deepcopy(self.row)
        row["artifacts"] = []
        self.assertTrue(grade.grade(row, self.retry_limit, self.citation))

    def test_infrastructure_failure_is_ineligible(self):
        row = copy.deepcopy(self.row)
        row["run"]["truncated"] = True
        self.assertFalse(grade.run_is_eligible(row))


if __name__ == "__main__":
    unittest.main()
