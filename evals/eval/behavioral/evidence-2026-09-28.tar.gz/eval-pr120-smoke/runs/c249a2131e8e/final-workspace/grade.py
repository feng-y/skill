import json
import re
from collections import defaultdict
from pathlib import Path


def expected_answer(surface):
    """Derive the frozen oracle from the authoritative document fixture."""
    match = re.fullmatch(
        r"Requests are retried at most (\d+) times\.",
        surface["document"]["content"],
    )
    if match is None:
        raise ValueError("document fixture no longer matches the deterministic oracle")
    return int(match.group(1)), surface["document"]["id"]


def run_is_eligible(row):
    """Infrastructure failures must not be counted as candidate failures."""
    run = row["run"]
    return (
        run.get("exit") == 0
        and run.get("truncated") is False
        and run.get("config_applied") is True
    )


def grade(row, retry_limit, citation):
    """Grade only the candidate-visible answer and citation requirements."""
    answer = row["answer"]
    return (
        answer.get("retry_limit") == retry_limit
        and answer.get("citation") == citation
    )


if __name__ == "__main__":
    surface = json.loads(Path("surface.json").read_text())
    records = json.loads(Path("records.json").read_text())
    retry_limit, citation = expected_answer(surface)
    ineligible = [row["id"] for row in records if not run_is_eligible(row)]
    if ineligible:
        raise RuntimeError(
            "ineligible runs must be retried or reported separately: "
            + ", ".join(ineligible)
        )
    output = {
        row["id"]: grade(row, retry_limit, citation)
        for row in records
    }
    Path("scores.json").write_text(json.dumps(output, indent=2) + "\n")

    summary = defaultdict(lambda: {"passed": 0, "total": 0})
    for row in records:
        bucket = summary[row["configuration"]]
        bucket["total"] += 1
        bucket["passed"] += int(output[row["id"]])
    for bucket in summary.values():
        bucket["pass_rate"] = bucket["passed"] / bucket["total"]

    print(json.dumps({"scores": output, "summary": summary}, indent=2))
