评估已写入 [findings.md](/code/b/skill-eval-runs/eval-pr120-smoke/runs/d694e367597e/workspace/findings.md)。

结论：

- 质量优化：不采用。selection 的 95% 上界 1.2 pp，仍低于批准的 2 pp 门槛。
- 成本优化：采用。成本降低约 28%，且 train、selection 的质量退化均守住 1 pp 护栏。
- 按 `eval` 的可信改进准则，archive 不可重新标为 held-out；selection 仅属选型证据，不能证明最终泛化。

仅新增评估文件，未修改实验、目标或执行部署。