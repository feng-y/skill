import unittest

from grade import grade


class GradeTest(unittest.TestCase):
    def test_accepts_contract_compliant_answer_without_artifact(self):
        self.assertTrue(grade({
            "answer": {"retry_limit": 3, "citation": "ops/retry"},
            "artifacts": [],
        }))

    def test_artifact_cannot_rescue_wrong_answer(self):
        self.assertFalse(grade({
            "answer": {"retry_limit": 4, "citation": "ops/retry"},
            "artifacts": ["audit.md"],
        }))

    def test_artifact_cannot_rescue_wrong_citation(self):
        self.assertFalse(grade({
            "answer": {"retry_limit": 3, "citation": "ops/other"},
            "artifacts": ["audit.md"],
        }))

    def test_rejects_missing_or_malformed_answer(self):
        self.assertFalse(grade({}))
        self.assertFalse(grade({"answer": "3"}))


if __name__ == "__main__":
    unittest.main()
