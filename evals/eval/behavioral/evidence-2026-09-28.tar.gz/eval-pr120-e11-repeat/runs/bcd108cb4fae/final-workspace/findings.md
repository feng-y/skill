# Documentation-agent eval audit findings

Audit date: 2026-09-28

## Decision

**Measurement status: `inconclusive` for the standard-versus-extended quality
decision.** Do not tune or adopt a configuration from the existing dashboard.

The repaired offline verifier is trustworthy for one much narrower claim: all
eight frozen answers satisfy this fixture's explicit answer-and-citation
contract. It does not establish production quality, generalization, a quality
gain, or configuration equivalence.

## Eval shape recovered from the repository

- **Capability:** answer an internal-document question accurately and cite the
  relevant document.
- **Task:** one retry-limit question whose reference answer is `3` and whose
  relevant document ID is `ops/retry`.
- **Environment:** one synthetic document, one read-only `read_document` tool,
  and two configurations. The records are a frozen synthetic diagnostic replay;
  no live answer-generation backend is connected.
- **Verifier:** `grade.py`, now a deterministic contract check over the answer
  value and citation.
- **Backend binding:** local offline replay via `python grade.py` over
  `records.json`.

## Evidence

### 1. The previous verifier contradicted the task contract

The visible task asks for an answer and citation. `surface.json` likewise lists
only `answer text` and `citation to the relevant document` in its artifact
contract. The old `grade.py` additionally required `audit.md`, although the task
does not request a file and every record correctly has an empty artifact list.

Observed effect before repair:

- `python grade.py` marked all 8 records false.
- The rejection was caused solely by the unrequested `audit.md` condition; each
  answer has `retry_limit: 3` and `citation: ops/retry`.

This was a verifier failure, not evidence of a candidate behavior failure.

### 2. The historical semantic scores are internally unreliable

There is only one unique serialized answer among all 8 records. Every record's
two semantic regrades use the same `same-output` hash but disagree (`true` once
and `false` once). Identical observable output therefore received opposite
judgments.

`dashboard.json` reports standard `0.25` and extended `0.0`, but those values
cannot be reproduced from the deterministic task contract or from a consistent
interpretation of the stored regrade events. The dashboard should be treated as
stale diagnostic evidence, not a quality measurement.

### 3. Repaired deterministic regrade

I removed the hidden file-delivery requirement and added verifier tests covering
the required positive case, wrong answer, wrong citation, irrelevant artifact,
missing answer, and malformed answer.

Commands and observed results:

```text
python -m unittest -v
Ran 4 tests in 0.000s
OK

python grade.py
standard: 4/4 = 1.00
extended: 4/4 = 1.00
paired deltas: [0, 0, 0, 0]; mean=+0.00
```

The new `scores.json` is reproducible from the frozen inputs. Adding an
`audit.md` artifact cannot rescue a wrong answer or wrong citation, and omitting
that unrequested artifact no longer causes a false failure.

### 4. Why the repaired scores still cannot answer the adoption question

- The sampler is explicitly the last 4 standard failures, with no successes and
  no other task families. Selection is neither representative nor independent
  of the configuration being evaluated.
- Although there are four `source_task` IDs, the recorded task surface contains
  only one question/document pair, and all eight answers are identical. This is
  effectively one behavioral case replayed across four labels, not coverage of
  documentation-agent quality.
- Four binary pairs have a 25 percentage-point minimum nonzero step, while the
  desired gain is 5 percentage points. The dataset cannot even resolve the
  target effect size, before considering uncertainty.
- `standard` changes both model and effort (`v1`/medium), while `extended`
  changes both (`v2`/high). Any future difference would be confounded, so this
  comparison would not identify which knob helped.
- These are frozen synthetic records, not fresh runs. They prove neither that a
  current runtime produces the answers nor that the behavior is stable across
  repeated runs.
- Run metadata records exit/truncation/config application, but not enough
  identity for a durable comparison (for example backend/harness version,
  prompt/config digest, seed or sampling settings, and timestamp).

Consequently, `100%` versus `100%` here means only that both stored outputs pass
one narrow deterministic check. It is not evidence that the configurations are
equivalent or production-ready.

## Changes made

- Repaired `grade.py` to grade only the explicit answer-and-citation contract and
  to reject missing or malformed answers cleanly.
- Added `test_grade.py` with contract and anti-proxy regression tests.
- Regenerated `scores.json` from the preserved `records.json` input.
- Preserved `records.json`, `surface.json`, `runtime.txt`, and `dashboard.json`.

## Recommended next steps, in order

1. **Stop using the dashboard for configuration decisions.** Keep the repaired
   deterministic grader as a regression check for this one case, and label this
   fixture a contract smoke test rather than a quality benchmark.
2. **Build a representative, preselected case set.** Sample independently of
   either configuration and stratify across real task shapes: direct lookup,
   multi-document synthesis, conflicting/stale documents, ambiguous questions,
   and cases where the corpus does not contain an answer. Include both historical
   successes and failures without selecting on one arm's outcome.
3. **Keep comparisons paired and isolate one variable.** Run the same cases and
   tool semantics for both arms. Compare model at fixed effort, or effort at a
   fixed model; do not change both at once.
4. **Make the verifier evidence-based and hard to game.** Derive expected facts
   and document IDs from held-out case fixtures; deterministically test factual
   answer, citation relevance, and abstention where appropriate. Add mutation
   tests for right answer/wrong citation, wrong answer/right citation,
   unsupported claims, and copied but irrelevant citations. Use a blinded
   independent semantic judge only where deterministic evidence is insufficient.
5. **Size the experiment for the 5-point decision before running it.** Twenty
   binary cases are only the arithmetic minimum for 5-point score granularity;
   they are not enough for a reliable estimate. Choose the sample size from the
   baseline rate and paired discordance, then report confidence intervals and
   raw paired outcomes rather than only means.
6. **Run fresh, repeated trials and preserve identity.** Record exact task-set
   version, runtime/prompt and configuration digests, model/backend and harness
   versions, sampling settings/seed where applicable, timestamps, tool calls and
   results, final artifacts, verifier version, and per-run judgment evidence.
   Inspect trajectories whenever a score changes before attributing the change
   to the candidate.

The next tuning target is therefore the **evaluation dataset and experiment
design**, not the agent prompt or effort setting. Revisit model/prompt tuning only
after a representative eval produces repeatable, attributable failure clusters.
