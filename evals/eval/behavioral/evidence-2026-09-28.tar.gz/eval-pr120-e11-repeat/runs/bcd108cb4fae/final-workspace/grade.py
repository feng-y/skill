import json
from pathlib import Path


def grade(row):
    """Grade only the answer and citation required by the task contract."""
    answer = row.get("answer", {})
    if not isinstance(answer, dict):
        return False
    return (answer.get("retry_limit") == 3
            and answer.get("citation") == "ops/retry")


if __name__ == "__main__":
    records = json.loads(Path("records.json").read_text())
    output = {row["id"]: grade(row) for row in records}
    Path("scores.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))
