审计与修正已完成，完整证据和建议见 [findings.md](/code/b/skill-eval-runs/eval-pr120-e11-repeat/runs/718571590d99/workspace/findings.md:1)。

核心结论：

- 旧分数主要来自评测故障：判分器要求任务未声明的 `audit.md`，且相同输出哈希被历史语义判分一正一负。
- 修正后 standard 与 extended 都是 4/4，差值 0pp。
- 当前离线重评可信，但配置升级结论仍为 `inconclusive`：只有一个合成任务形状，没有实时代理运行或代表性样本。
- 下一步应先扩建评测集并接入成对实时运行，暂时没有证据支持调整 prompt 或提高 effort。

已完成：

- 修复 [grade.py](/code/b/skill-eval-runs/eval-pr120-e11-repeat/runs/718571590d99/workspace/grade.py:10)，移除隐藏要求，并将无效运行与代理失败分开。
- 添加 5 个抗投机测试：[test_grade.py](/code/b/skill-eval-runs/eval-pr120-e11-repeat/runs/718571590d99/workspace/test_grade.py:12)。
- 生成重评结果：[scores.json](/code/b/skill-eval-runs/eval-pr120-e11-repeat/runs/718571590d99/workspace/scores.json)。
- `python -m unittest -v`：5/5 通过。
- `python grade.py`：两种配置均为 100%。