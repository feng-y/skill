import json
import re
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def load_contract(surface):
    """Build the deterministic grading contract from candidate-visible inputs."""
    document = surface["document"]
    match = re.fullmatch(r"Requests are retried at most (\d+) times\.",
                         document["content"])
    if match is None:
        raise ValueError("unsupported retry-document wording")
    return {
        "retry_limit": int(match.group(1)),
        "citation": document["id"],
        "configurations": set(surface["configurations"]),
    }


def grade(row, contract):
    """Grade only observable requirements from the task and runtime surface."""
    answer = row.get("answer", {})
    run = row.get("run", {})
    if not (run.get("exit") == 0
            and run.get("truncated") is False
            and run.get("config_applied") is True):
        return None
    if row.get("configuration") not in contract["configurations"]:
        return None
    if not (type(answer.get("retry_limit")) is int
            and answer["retry_limit"] == contract["retry_limit"]
            and answer.get("citation") == contract["citation"]):
        return False

    trajectory = row.get("trajectory", [])
    reads = [event.get("result") for event in trajectory
             if event.get("tool") == "read_document"]
    saw_supporting_read = any(
        result.get("id") == contract["citation"]
        and result.get("retry_limit") == contract["retry_limit"]
        for result in reads if isinstance(result, dict)
    )
    finals = [event["final"] for event in trajectory if "final" in event]
    return saw_supporting_read and bool(finals) and finals[-1] == answer


def summarize(records, scores):
    grouped = defaultdict(list)
    for row in records:
        grouped[row["configuration"]].append(scores[row["id"]])
    output = {}
    for name, results in sorted(grouped.items()):
        valid = [result for result in results if result is not None]
        output[name] = {
            "passed": sum(valid),
            "valid_runs": len(valid),
            "invalid_runs": len(results) - len(valid),
            "rate": sum(valid) / len(valid) if valid else None,
        }
    return output


if __name__ == "__main__":
    surface = json.loads((ROOT / "surface.json").read_text())
    records = json.loads((ROOT / "records.json").read_text())
    contract = load_contract(surface)
    scores = {row["id"]: grade(row, contract) for row in records}
    (ROOT / "scores.json").write_text(json.dumps(scores, indent=2) + "\n")
    print(json.dumps({"scores": scores, "summary": summarize(records, scores)},
                     indent=2))
