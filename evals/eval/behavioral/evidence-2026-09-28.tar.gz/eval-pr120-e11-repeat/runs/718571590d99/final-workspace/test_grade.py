import copy
import json
import unittest
from pathlib import Path

from grade import grade, load_contract


ROOT = Path(__file__).resolve().parent


class GradeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        surface = json.loads((ROOT / "surface.json").read_text())
        cls.contract = load_contract(surface)
        cls.row = json.loads((ROOT / "records.json").read_text())[0]

    def test_valid_answer_needs_no_undeclared_artifact(self):
        self.assertEqual(self.row["artifacts"], [])
        self.assertTrue(grade(self.row, self.contract))

    def test_rejects_wrong_answer_even_when_trajectory_matches_it(self):
        row = copy.deepcopy(self.row)
        row["answer"]["retry_limit"] = 4
        row["trajectory"][-1]["final"]["retry_limit"] = 4
        self.assertFalse(grade(row, self.contract))

    def test_rejects_wrong_citation_even_when_trajectory_matches_it(self):
        row = copy.deepcopy(self.row)
        row["answer"]["citation"] = "other/doc"
        row["trajectory"][-1]["final"]["citation"] = "other/doc"
        self.assertFalse(grade(row, self.contract))

    def test_rejects_answer_without_supporting_document_read(self):
        row = copy.deepcopy(self.row)
        row["trajectory"] = row["trajectory"][1:]
        self.assertFalse(grade(row, self.contract))

    def test_rejects_invalid_run(self):
        row = copy.deepcopy(self.row)
        row["run"]["truncated"] = True
        self.assertIsNone(grade(row, self.contract))


if __name__ == "__main__":
    unittest.main()
