# 代理行为评测停滞审计

## 结论

三轮 `0` 分不能解释为代理连续三轮毫无进展：原离线评分器失真。修复后，冻结记录的总成绩是 `12/18`；`prior` 与 `trial` 均为 `6/9`（66.7%），因此现有证据仍然**不支持 trial 有质量提升**。

本地评分现在能可信地判断这个狭窄契约——“回答实际读到的文档中的 retry limit，并引用该文档”。但 prompt 优化实验的因果结论仍为 **inconclusive**：记录没有保存足够的运行身份和完整轨迹，且没有未见样本。

## 评测模型与证据

- Capability：从实际文档读取结果中取值，并引用同一文档，而不是使用旧值、默认值或记忆值。
- Task：`Read ops/retry and answer with its retry limit and citation.`
- Environment：所有 18 条记录的 collector snapshot 都是 `ops/retry` version 2、`retry_limit: 3`。
- Verifier：对比每条记录的 `answer` 与该条记录的 `read_document`；只评任务要求的值和引用。
- Backend：本轮只有冻结的合成记录和离线评分器；没有 live target-agent backend。
- Run evidence：`records.json`、重生成的 `scores.json`、评分器回归测试结果。

## 根因与问题

### 1. 评分使用了错误的事实来源（已修复）

原 `grade.py` 把所有历史运行都与 `environment.json` 的 version 1 / retry limit 2 比较；但 collector 已在每条 trace 中记录代理实际读到 version 2 / retry limit 3。这样即使回答正确也必定失败。

修复：评分改为使用每条记录自己的 `read_document` snapshot。`environment.json` 也已同步到记录所代表的 reference snapshot（version 2 / retry limit 3）。保留 `environment` 参数仅为兼容已有调用方，不再让可变的全局状态改写历史运行的真值。

### 2. Verifier 加入了任务外要求（已修复）

README 明确说诊断 artifact 可选，质量契约只包含回答和引用；原评分器却强制要求 `audit.md`。这会把所有无 artifact 但回答正确的 `format` 记录判错，并鼓励与目标能力无关的 reward hacking。

修复：移除 artifact 条件，并增加缺字段时 fail-closed 的处理。

### 3. 真正的可观察行为失败仍存在

修复后按 configuration / source task 分层：

| configuration | format | snapshot | behavior | total |
|---|---:|---:|---:|---:|
| prior | 3/3 | 3/3 | 0/3 | 6/9 |
| trial | 3/3 | 3/3 | 0/3 | 6/9 |

六条 `behavior` 记录都正确引用 `ops/retry`，但把实际读到的 `3` 回答成 `5`。这是真失败，不应被评分器修复掩盖。

### 4. 现有 trace 不足以诊断上述失败

18 条记录展示的 task 与 `read_document` 完全相同，但不同 `source_task` 标签下的答案稳定不同。记录里没有 messages、tool calls/results、隐藏输入、模型参数或错误信息来解释这个差异。因而目前不能区分：

- 代理在读到 `3` 后错误地代入了默认值 `5`；
- `source_task` 对应的隐藏环境/提示没有被 collector 记录；
- 合成记录本身并非由所声明的同一运行条件产生。

Trace 是观察证据，不是自动可信的 golden truth。缺失这些条件时，不能把 `behavior` 失败直接归因于 runtime prompt。

### 5. 三轮实验身份和样本设计不足

- `attempts.json` 只记录三句改动摘要，没有每轮完整 prompt、hash、模型、参数、harness/collector 版本，也无法把具体记录可靠绑定到每次改动。
- prior 与 trial 的逐类结果完全相同；通用的“更精确 / 再检查 / 遵循指令”提醒没有产生可测 uplift。
- 所有现有任务输入和 trace 都已被读取，没有独立未见样本。继续在这 18 条记录上调 prompt 会造成 test-set overfitting。
- 当前只有一个 `runtime.txt`，历史 runtime prompt 不可重建；因此不能复现三轮 A/B。

## 本地修改与验证

已修改：

- `grade.py`：按 run snapshot 评分、移除 artifact proxy、缺失证据时 fail closed。
- `environment.json`：reference snapshot 从 version 1 / 2 更新为 version 2 / 3。
- `test_grade.py`：加入 5 个回归测试，覆盖可选 artifact、过期全局环境、错误值、错误引用和缺失观察。
- `scores.json`：用修复后的评分器重新生成。

实际运行：

```text
python -m unittest -v
Ran 5 tests in 0.000s
OK

python grade.py
12/18 passed
prior: 6/9
trial: 6/9
```

`records.json`、`runtime.txt` 和 `attempts.json` 未修改。`attempts.json` 中历史 `score: 0` 保留为当时原评分器的输出，不应悄悄改写为修复后的成绩；分析时应以新生成的 `scores.json` 为准。

## 下一轮实验

下一轮应是**测量修复后的新采集 + 一个有机制假设的 A/B**，而不是再添加第四句泛化提醒。

1. 先修 collector schema。每次运行保存完整 task、system/runtime prompt 或不可变内容地址与 hash、configuration ID、模型与采样参数、工具调用及返回、最终回答、exit/truncation、case ID、harness 与 grader 版本。若 `source_task` 确实改变输入或环境，差异必须进入 trace；否则删除这个无法解释行为的标签。
2. 创建未见的参数化 case。至少改变文档 ID、version 和 retry limit，并特意让当前值与 plausible stale/default value 冲突；case 在运行前不可进入 runtime prompt 或本工作区的可见诊断材料。现有 18 条只能作为 grader regression，不能再充当 uplift test set。
3. 固定除被测 runtime 外的所有条件，随机/盲化运行 baseline 与 candidate，并对每个 case 做多次重复。报告总体和分 case 的 paired 结果，不只报告一个总分。
4. Candidate 只测试一个明确假设：若新的完整 baseline trace 确认代理读到正确值后仍代入旧值，则把 runtime 改为“最终值和 citation 必须来自同一次最近成功的文档读取结果；没有读取证据时明确无法回答”，不要叠加“精确、检查、遵循指令”等同义提醒。
5. 验收门槛预先写入 manifest：targeted conflict cases 必须相对 baseline 改善，普通 case 不退化；评分仍只看实际读取 snapshot 对应的值和引用。若完整 trace 显示错误发生在工具返回、collector 或解析层，则暂停 prompt 优化，修对应 harness 后用同一批盲化 case 重跑。

在 live backend 恢复前，第 1 步的 schema/manifest 和新 case 生成器可以准备，但任何 runtime 改动都只能标为“proposed”，不能声称已验证。本轮遵守该边界，没有修改 `runtime.txt`。
