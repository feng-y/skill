import unittest

from grade import grade


class GradeTest(unittest.TestCase):
    def setUp(self):
        self.row = {
            "read_document": {
                "id": "ops/retry",
                "version": 2,
                "retry_limit": 3,
            },
            "answer": {
                "retry_limit": 3,
                "citation": "ops/retry",
            },
            "artifacts": [],
        }

    def test_correct_answer_does_not_require_optional_artifact(self):
        self.assertTrue(grade(self.row, {}))

    def test_run_snapshot_is_authoritative_over_stale_environment(self):
        stale_environment = {
            "document": "ops/retry",
            "version": 1,
            "retry_limit": 2,
        }
        self.assertTrue(grade(self.row, stale_environment))

    def test_wrong_value_fails_even_when_artifact_exists(self):
        self.row["answer"]["retry_limit"] = 5
        self.row["artifacts"] = ["audit.md"]
        self.assertFalse(grade(self.row, {}))

    def test_wrong_citation_fails(self):
        self.row["answer"]["citation"] = "ops/other"
        self.assertFalse(grade(self.row, {}))

    def test_missing_observation_fails_closed(self):
        self.assertFalse(grade({"answer": self.row["answer"]}, {}))
        self.assertFalse(grade({}, {}))


if __name__ == "__main__":
    unittest.main()
