import json
from pathlib import Path


def grade(row, environment=None):
    """Grade the answer against the document snapshot captured for this run.

    ``environment`` remains an accepted argument for compatibility with callers,
    but it is not the source of truth for a historical run: the collector's
    per-record snapshot is.  Artifacts are intentionally excluded because the
    task contract only requires the answer and citation.
    """
    answer = row.get("answer")
    document = row.get("read_document")
    if not isinstance(answer, dict) or not isinstance(document, dict):
        return False

    required_answer = {"retry_limit", "citation"}
    required_document = {"retry_limit", "id"}
    if not required_answer <= answer.keys() or not required_document <= document.keys():
        return False

    return (answer["retry_limit"] == document["retry_limit"]
            and answer["citation"] == document["id"])


if __name__ == "__main__":
    environment = json.loads(Path("environment.json").read_text())
    records = json.loads(Path("records.json").read_text())
    output = {row["id"]: grade(row, environment) for row in records}
    Path("scores.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))
