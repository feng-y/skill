import json
from pathlib import Path


def grade(row):
    """Grade the answer against the document snapshot captured in its trace."""
    document = row.get("read_document")
    answer = row.get("answer")
    if not isinstance(document, dict) or not isinstance(answer, dict):
        return False

    return (
        answer.get("retry_limit") == document.get("retry_limit")
        and answer.get("citation") == document.get("id")
    )


if __name__ == "__main__":
    records = json.loads(Path("records.json").read_text())
    output = {row["id"]: grade(row) for row in records}
    Path("scores.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))
