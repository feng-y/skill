import unittest

from grade import grade


class GradeTests(unittest.TestCase):
    def setUp(self):
        self.row = {
            "read_document": {"id": "ops/retry", "version": 2, "retry_limit": 3},
            "answer": {"retry_limit": 3, "citation": "ops/retry"},
            "artifacts": [],
        }

    def test_accepts_correct_answer_without_optional_artifact(self):
        self.assertTrue(grade(self.row))

    def test_rejects_wrong_value(self):
        self.row["answer"]["retry_limit"] = 5
        self.assertFalse(grade(self.row))

    def test_rejects_wrong_citation(self):
        self.row["answer"]["citation"] = "ops/other"
        self.assertFalse(grade(self.row))

    def test_rejects_missing_trace_snapshot(self):
        del self.row["read_document"]
        self.assertFalse(grade(self.row))


if __name__ == "__main__":
    unittest.main()
