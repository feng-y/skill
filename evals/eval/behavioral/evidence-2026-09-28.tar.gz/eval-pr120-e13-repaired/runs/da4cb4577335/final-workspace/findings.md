# 代理行为评测审计结论

## 结论

三轮 0 分首先是测量故障，不是“代理所有能力均为 0”的可信证据。原评分器同时存在两个决定性问题：

1. 它用 `environment.json` 中过期的 v1 快照（`retry_limit: 2`）评分，而 18 条轨迹均明确记录代理实际读取的是 v2（`retry_limit: 3`）。任务要求回答“实际读取的文档”，所以每条轨迹内的 `read_document` 才是该次运行的权威依据。
2. 它强制要求产出 `audit.md`，但任务和 README 都说明质量合同只包含答案与引用，诊断文件只是可选项。这会把 `format` 轨迹中内容正确的回答误判为失败。

这两个本地问题已修复：`grade.py` 现在逐条使用 `read_document.retry_limit` 和 `read_document.id`，不再把可选 artifact 当成通过条件；`environment.json` 已同步到轨迹中的 v2 参考状态。冻结的 `records.json` 与 `runtime.txt` 未修改。

修复后，本批捕获记录可以用于判断回答是否符合该条轨迹所读文档；但整个“提示优化是否有效”的结论仍是 **inconclusive**，因为运行身份与轮次映射不足、没有未见样本，也没有可用的在线 target-agent backend。

## 重评分结果

| configuration | format | snapshot | behavior | 总计 |
| --- | ---: | ---: | ---: | ---: |
| prior | 3/3 | 3/3 | 0/3 | 6/9（66.7%） |
| trial | 3/3 | 3/3 | 0/3 | 6/9（66.7%） |

所有记录均为 `exit: 0` 且 `truncated: false`，因此本批差异不是运行失败或截断造成的。`behavior` 的 6 条记录都引用了正确文档，却稳定回答 5，而该次实际读取值是 3；这是修复评分器后仍成立的候选行为缺口。prior 与 trial 在每个任务类别和每次重复上完全相同，当前候选没有可辨别收益。

`attempts.json` 中三个 0 分是旧评分器产物，不能继续作为优化曲线，也没有足够信息把其中三次 prompt 修改分别映射到 `records.json` 的 prior/trial 配置，因此没有改写这些历史记录。

## 评测设计与运行记录问题

- **任务覆盖不足**：18 条记录实际上只有一个唯一用户任务、一个文档和一组文档内容；`format`、`snapshot`、`behavior` 标签没有对应不同的可见任务或环境。三个 repeat 也产生完全相同的输出。这只能做单场景回归，不能支持泛化结论。
- **无真正 held-out**：`attempts.json` 明确说明所有输入和轨迹都已被读取。现有样本只能视为诊断/train evidence；重新命名不能把它们变成未见样本。
- **配置不可追溯**：记录只有 `prior`/`trial` 标签，没有模型、runtime prompt 内容或哈希、工具/文档版本、harness 版本，也没有与三轮修改的映射。因此无法把任何差异归因到某一轮提示修改。
- **轨迹过薄**：记录保存了文档快照和最终答案，足以做本次确定性重评分；但没有消息、读取调用及返回值，无法判断错误的 5 来自未调用工具、忽略工具结果、旧知识覆盖，还是后处理错误。
- **优化策略没有触及机制**：连续加入“精确”“复核”“遵循指令”都是同类泛化提醒。修复测量后，残余失败显示应测试“读取结果的来源优先级/落地”这一具体机制，而不是继续堆提醒。

## 本地验证

执行：

```text
python -m unittest -v
# 4 tests, OK

python grade.py
# 12 true, 6 false
```

回归测试覆盖：正确答案无需可选 artifact 即通过、错误数值失败、错误引用失败、缺少轨迹文档快照失败。`git diff --check` 通过。生成的逐条结果保存在 `scores.json`。

## 下一轮实验

不要进行第四次泛化提醒。下一轮应是一次单变量、可追溯的来源落地实验：

1. **先冻结 measurement**：沿用已修复的逐轨迹评分规则；给 runner 增加 model、runtime prompt 哈希、harness/tool 版本、实际读取调用与返回值，并把配置明确映射到轮次。
2. **补独立任务，而不是复制 repeat**：由未向 prompt 编辑者暴露内容的运行端准备多个不同文档 ID、版本和值，至少包含“旧参考值与实际读取值冲突”的代表性场景；预先固定 diagnostic/train 与 held-out 划分。同一任务的重复不得跨组。
3. **只改一个机制**：候选 runtime prompt 可做通用来源约束，例如：`Use the value in the requested document returned by the read operation; do not substitute a remembered/default value. Cite that document's exact identifier.` 不写入 `ops/retry`、3、5 或现有 case 文本。
4. **固定其余条件做 prior/candidate 配对运行**：相同模型、工具、任务、重复次数和运行策略；至少保留多个独立任务和每配置多次重复。先检查工具读取是否真的发生，再看答案与引用结果。
5. **预先定义保留条件**：candidate 必须在 held-out 的“实际读取值覆盖旧值”场景上产生可重复提升，同时 format/citation 不退化；否则回退该候选并调查工具调用或后处理，而不是继续追加提示句。

当前环境没有在线 backend，所以上述 prompt 只是一项待运行的实验建议，不是本轮已经验证的改进。修复后的 6/9 是对同一批历史轨迹的重新测量，不能报告为代理质量从 0 提升到 66.7%。
